//const ip='https://apidev.fanconvo.com';
// const ip='http://127.0.0.1:8000';
// const ip='https://auth.fanconvo.com';
const ip='https://admin.fanconvo.com';
// const ip='http://django-env.eba-hgpcimh3.us-west-1.elasticbeanstalk.com/';
// const ip='http://fanconvodev-env.us-west-1.elasticbeanstalk.com';

export const myConfig = { 
  apiUrl: ip+'/api/v3/',
  baseUrl: ip,
  captchaKey: '6Lf6bDIaAAAAAPNNYQvRItU7sbSqszy28MtCyi-G'
};