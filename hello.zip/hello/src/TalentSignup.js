import React, { Component } from "react";
import './style.css';
import axios from 'axios';
import ReCAPTCHA from "react-google-recaptcha";
import * as config from './config';
import $ from 'jquery';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';

// let defaultOptions;
export default class TalentSignup extends React.Component {
  constructor(props){
    super(props);
    this.state = {
       fields: {
          first_name: '',
          last_name: '',
          email: '', 
          password:'',
          username: ''
        },
        timezone: "",
        timezone_list: [],
        errors: {},
        success_msg: {},
        checked: true,
        captcha: false,
        captcha_err: '',
        btnSpinner: false,
        hideForm: false,
        phone: ''
    };

    this.handleChange = this.handleChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.chBox_handle = this.chBox_handle.bind(this);
    this.captchaChange = this.captchaChange.bind(this);
    this.timezoneChange = this.timezoneChange.bind(this);
    this.phone_handle = this.phone_handle.bind(this);

    this.get_timezones();
  }

//   componentDidMount() {
//     // $('.time-zone-signup').select2({minimumInputLength: 2}).on("change", this.timezoneChange);
//     $('.time-zone-signup').select2().on("change", this.timezoneChange);
//     this.setState({
//       timezone: 'PST8PDT'
//     });
//   }

  timezoneChange(e){
    this.setState({
      timezone: e.target.value
    });
  }

   //get timezones
   get_timezones(){
    axios.get(config.myConfig.apiUrl+'time_zones')
    .then((response) => {
      let timezone_list = response.data.data;
      this.setState({ 
        timezone_list: timezone_list
      })
    }).catch(error =>{
      console.log(error.response);
    });
  }

  handleChange(e) {
    let fields = this.state.fields;
    if(e.target.name == 'password'){
      fields[e.target.name] = e.target.value.replace(/^\s+|\s+$/g, "");  
    } else {
      fields[e.target.name] = e.target.value;  
    }
    this.setState({
      fields:this.state.fields
    });
  }

  chBox_handle() {
    this.setState({
      checked: !this.state.checked
    })
  }

  captchaChange(value) {
    if((value !== null) && (value !== '')){
      this.setState({ captcha: true });
    } else {
      this.setState({ captcha: false });
    }
  }

  phone_handle(e) {
    this.setState({
      phone : e
    });
    console.log("Phone", e);
  }
    
  onSubmit = (e) => {
    e.preventDefault();

    this.setState({
      btnSpinner: true
    });
 
    let fields = this.state.fields; 
    let errors = {};  
    let success_msg = {};   
    const first_name = fields.first_name;
    const last_name = fields.last_name;
    const email = fields.email.toLowerCase();   
    const password = fields.password;
    const username = fields.username.toLowerCase();
    const phone = this.state.phone;
    const captcha = this.state.captcha;
    const timezone = this.state.timezone;
      
    axios.post(config.myConfig.apiUrl+'sign-up/talent', { first_name, last_name, email, password, timezone, username, captcha, phone })
    .then((response) => {
      console.log(response.data);
      success_msg["success"] = response.data.message;
      this.setState({
        btnSpinner: false,
        success_msg: success_msg,
        hideForm: true
      });
    }).catch(error =>{
      console.log(error.response)

      if(error.response == undefined){
        errors["non_field_errors"] = 'Oops, something went wrong. We are working on getting this fixed. Try reloading this page';
      } else {
         errors = error.response.data.data;
         this.focusInputOnErr(errors);
      }

      this.setState({
        errors: errors,
        success_msg: {},
        btnSpinner: false
      });
    });
    
  }

  focusInputOnErr(errors){
    let fieldKeys = Object.keys(this.state.fields);
    for (var key of Object.keys(errors)) {
      if(fieldKeys.indexOf(key) > -1){
        var nameObj = document.getElementsByName(key);
        nameObj[0].focus();
        nameObj[0].scrollIntoView();
        break;
      }
    }
  }


  



  render() {
    return (
      
        <div className="container fanc-signup">
          <div className="justify-content-center fanco-outer-account signup fanc-forms">
            {(this.state.hideForm == false) ? (
              <>
                {/*<div className="col-12 text-center">
                  <p className="account-head tag-line">Create Your Talent Account</p>            
                </div> */}
                <div class="row justify-content-center">
                  <div className="col-lg-9 col-md-12 col-sm-12">
                    <form id="form-style-1" className="account-form" autocomplete="off" onSubmit = {this.onSubmit}>
                      <div className="form-row">
                        <div className="form-group pt-2 col-md-6">
                          <label>First name *</label> 
                          <input type="text" className="form-control custom-fields-green" id="formGroupInput1" placeholder="First name" name="first_name" autocomplete="off" value={this.state.fields.first_name} onChange={this.handleChange}  />                            
                          <div className="errorMsg">{this.state.errors.first_name}</div>
                        </div>
                        <div className="form-group pt-2 col-md-6">
                          <label>Last name </label>                            
                          <input type="text" className="form-control custom-fields-green" id="formGroupInput2" placeholder="Last name" name="last_name" autocomplete="off" value={this.state.fields.last_name} onChange={this.handleChange}  />
                          <div className="errorMsg">{this.state.errors.last_name}</div>
                        </div>
                      </div>

                      <div className="form-row">
                        <div className="form-group pt-2 col-md-6">
                          <label>Username *</label>                           
                            <input type="text" maxLength="50" className="form-control custom-fields-green lowercase" id="formGroupInput21" placeholder="Username" name="username" autocomplete="off" value={this.state.fields.username} onChange={this.handleChange}  />
                            <div className="errorMsg">{this.state.errors.username}</div>
                        </div>
                        <div className="form-group pt-2 col-md-6"> 
                          <label>Email *</label>                           
                          <input type="text" className="form-control custom-fields-green lowercase" id="inputEmail3" placeholder="Email" name="email" autocomplete="off" value={this.state.fields.email} onChange={this.handleChange}/>
                          <div className="errorMsg">{this.state.errors.email}</div>
                        </div>
                      </div>

                      <div className="form-row">
                        <div className="form-group pt-2 col-md-6">
                          <label>Phone *</label>                           
                            <PhoneInput
                              country={'us'}
                              inputClass="custom-fields-green"
                              value={this.state.phone}
                              onChange={this.phone_handle}
                            />
                            <div className="errorMsg">{this.state.errors.phone}</div> 
                        </div>
                        <div className="form-group pt-2 col-md-6">
                          <label>Password *</label>                            
                          <input type="password" maxLength="50" className="form-control custom-fields-green" id="inputPassword4" placeholder="Password" name="password" autocomplete="off" value={this.state.fields.password} onChange={this.handleChange} />
                          <div className="errorMsg">{this.state.errors.password}</div>
                        </div>
                      </div>
                      <div className="form-group pt-2">
                        <label>Timezone *</label>    
                        <select class="time-zone-signup form-control custom-fields-green" name="timezone" onChange={this.timezoneChange} >
                              {this.state.timezone_list.map((zone, index) => { 
                                return(
                                  <option key={index} value={zone.value} selected={this.state.timezone === zone.value}>{zone.value} - {zone.time}</option>
                                )
                              })}
                        </select>
                        <div className="errorMsg">{this.state.errors.timezone}</div>
                      </div>
                      <div className="form-row justify-content-center">
                        <div className="form-group captcha pt-4 pl-3">
                          <ReCAPTCHA
                            sitekey={config.myConfig.captchaKey}
                            onChange={this.captchaChange}
                            theme="dark"
                          />
                          <div className="errorMsg">{this.state.errors.captcha}</div>
                        </div>
                      </div>
                      <div className="something-wrong errorMsg">{this.state.errors.non_field_errors}</div>
                      <div className="form-group reg-agree pt-4">
                        <div className="custom-control custom-checkbox">
                          <input type="checkbox" className="custom-control-input" id="customCheck1" checked={ this.state.checked } onChange={ this.chBox_handle }/>
                          <label className="custom-control-label" htmlFor="customCheck1">I agree to the <a href="/terms-of-use" target="_blank">Terms and Conditions.</a></label>
                        </div>
                      </div>
                      <div className="form-group text-center pt-4">
                        <button type="submit" className="btn custom-button-green btn-lg" disabled={!this.state.checked}>
                          {(this.state.btnSpinner == true) && (
                            <div className="spinner"><div></div><div></div><div></div><div></div></div>
                          )}
                          Sign up
                        </button>
                        <p className="pt-2 login-control-label"> Already have an account? <a href="/login" className="green-link"> Log in</a></p>
                      </div>
                    </form>
                  </div>
                </div>
              </>  
              ) : (
                  <div className="errorMsg success text-center">{this.state.success_msg.success}</div>
            )} 
          </div>
        </div>
    )
  }
}