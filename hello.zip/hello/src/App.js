import react from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

import './App.css';
// import {BsSearch} from 'react-icons/bs';
import {BrowserRouter as Router,Route,Switch,Redirect} from "react-router-dom";
import SignupTalentPage from './fanSignup';
import SignupFanPage from './TalentSignup';


function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/" />
        <Route exact path="/talentpage" component={SignupTalentPage} />
        <Route exact path="/fanpage" component={SignupFanPage} />
        </Switch>
        </Router>
 
  );
}

export default App;
